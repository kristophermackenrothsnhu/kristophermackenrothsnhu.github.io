import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { TripDataService } from '../services/trip-data';
import { Trip } from '../models/trip';

/**
 * AddTripComponent
 *
 * Provides functionality for creating a new trip.
 * Uses a template-driven form to collect trip details
 * and submits them to the backend service.
 */
@Component({
  selector: 'app-add-trip',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-trip.html',
  styleUrls: ['./add-trip.css']
})
export class AddTripComponent {

  /**
   * Model bound to the add trip form.
   * Initialized with default values to prevent null references.
   */
  public newTrip: Trip = {
    code: '',
    name: '',
    length: 0,
    start: new Date(),
    resort: '',
    perPerson: 0,
    image: '',
    description: ''
  };

  /** Indicates whether a submission is in progress */
  public loading = false;

  /** Error message displayed to the user */
  public error = '';

  /** Success message displayed to the user */
  public success = '';

  constructor(
    private tripDataService: TripDataService,
    private router: Router
  ) {}

  /**
   * Handles form submission and creates a new trip.
   */
  public onSubmit(): void {
  this.loading = true;
  this.error = '';
  this.success = '';

  // ✅ Normalize fields before sending to API
  const formattedTrip: Trip = {
    ...this.newTrip,
    length: Number(this.newTrip.length),
    perPerson: Number(this.newTrip.perPerson),
    start: new Date(this.newTrip.start) // 🚀 THIS WAS MISSING
  };

  this.tripDataService.addTrip(formattedTrip).subscribe({
    next: () => {
      this.success = 'Trip added successfully!';
      this.loading = false;
      this.router.navigate(['']);
    },
    error: err => {
      console.error('Trip creation failed:', err);
      this.error = 'Trip creation failed. Make sure you are logged in.';
      this.loading = false;
    }
  });
}

}
