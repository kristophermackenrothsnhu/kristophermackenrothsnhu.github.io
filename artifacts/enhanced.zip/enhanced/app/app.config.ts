import {
  ApplicationConfig,
  provideBrowserGlobalErrorListeners
} from '@angular/core';

import { provideRouter } from '@angular/router';
import {
  provideHttpClient,
  withInterceptorsFromDi
} from '@angular/common/http';

import { routes } from './app.routes';
import { authInterceptProvider } from './utils/jwt-interceptor';

/**
 * Application Configuration
 *
 * Centralized bootstrap configuration for the
 * Travlr Getaways Admin application.
 */
export const appConfig: ApplicationConfig = {
  providers: [

    provideBrowserGlobalErrorListeners(),

    provideRouter(routes),

    // ✅ THIS IS THE FIX
    provideHttpClient(withInterceptorsFromDi()),

    // JWT interceptor (now actually used)
    authInterceptProvider
  ]
};
