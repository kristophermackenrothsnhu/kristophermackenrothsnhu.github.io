import { Routes } from '@angular/router';
import { AddTripComponent } from './add-trip/add-trip';
import { TripListingComponent } from './trip-listing/trip-listing';
import { EditTripComponent } from './edit-trip/edit-trip';
import { LoginComponent } from './login/login';
import { RegisterComponent } from './register/register';

/**
 * Application Route Configuration
 *
 * Defines all client-side navigation paths for the
 * Travlr Getaways Admin application.
 *
 * Design Considerations:
 * - Routes are centralized for maintainability and clarity
 * - Standalone components are used to reduce module overhead
 * - Parameterized routes enable dynamic navigation (e.g., edit-trip)
 * - AuthGuards can be added later without restructuring routes
 */
export const routes: Routes = [

  /**
   * Default route
   * Displays the list of trips after successful login
   */
  {
    path: '',
    component: TripListingComponent,
    pathMatch: 'full'
  },

  /**
   * Create a new trip
   * (Future enhancement: protect with AuthGuard)
   */
  {
    path: 'add-trip',
    component: AddTripComponent
  },

  /**
   * Edit an existing trip
   * Uses a route parameter to identify the trip by its code
   */
  {
    path: 'edit-trip/:tripCode',
    component: EditTripComponent
  },

  /**
   * User authentication routes
   */
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  },

  /**
   * Wildcard route
   * Redirects unknown paths to the home page
   * Improves UX and prevents navigation errors
   */
  {
    path: '**',
    redirectTo: ''
  }
];
