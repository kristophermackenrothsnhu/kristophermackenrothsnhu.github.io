import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './navbar/navbar';

/**
 * App Component
 *
 * Root component for the Travlr Getaways Admin application.
 * This component serves as the application shell and is responsible for:
 * - Rendering the persistent navigation bar
 * - Hosting the router outlet for all routed views
 *
 * Design Notes:
 * - Uses Angular standalone components to reduce module complexity
 * - Uses Angular signals for lightweight, reactive state management
 * - Contains no business logic to maintain clean separation of concerns
 */
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,   // Provides common Angular directives and pipes
    RouterOutlet,   // Displays routed components
    NavbarComponent // Persistent application navigation bar
  ],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {

  /**
   * Application title signal.
   * Signals provide reactive state updates with minimal overhead,
   * making them well-suited for simple UI-driven state.
   */
  protected readonly title = signal('Travlr Getaways Admin');

  /**
   * Updates the application title.
   * This method demonstrates controlled state mutation and
   * keeps UI state changes explicit and predictable.
   *
   * @param newTitle - The new title to display
   */
  public updateTitle(newTitle: string): void {
    this.title.set(newTitle);
  }
}
