import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import {
  ReactiveFormsModule,
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';

import { TripDataService } from '../services/trip-data';
import { Trip } from '../models/trip';

/**
 * EditTripComponent
 *
 * Provides functionality for editing an existing trip.
 * Loads trip data based on the route parameter and binds it
 * to a reactive form for validation and submission.
 */
@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.html',
  styleUrls: ['./edit-trip.css']
})
export class EditTripComponent implements OnInit {

  /** Reactive form used to edit trip details */
  public editForm!: FormGroup;

  /** Indicates whether the form has been submitted */
  public submitted = false;

  /** Message displayed to the user for success or error feedback */
  public message = '';

  /** Indicates whether a data request is in progress */
  public isLoading = false;

  /** Currently loaded trip data */
  private trip!: Trip;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private tripDataService: TripDataService
  ) {}

  /**
   * Initializes the component by retrieving the trip code
   * from the route and loading the corresponding trip data.
   */
  ngOnInit(): void {
    const tripCode = this.route.snapshot.paramMap.get('tripCode');

    if (!tripCode) {
      alert('Unable to locate trip information.');
      this.router.navigate(['']);
      return;
    }

    this.buildForm(tripCode);
    this.loadTrip(tripCode);
  }

  /**
   * Builds the reactive form with validation rules.
   */
  private buildForm(tripCode: string): void {
    this.editForm = this.formBuilder.group({
      _id: [],
      code: [tripCode, Validators.required],
      name: ['', [Validators.required, Validators.minLength(3)]],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', [Validators.required, Validators.minLength(3)]],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', [Validators.required, Validators.minLength(10)]]
    });
  }

  /**
   * Loads trip data from the backend using the trip code.
   */
  private loadTrip(tripCode: string): void {
    this.isLoading = true;

    this.tripDataService.getTrip(tripCode).subscribe({
      next: (trip) => {
        this.isLoading = false;
        if (trip) {
          this.trip = trip;
          this.editForm.patchValue(trip);
        } else {
          this.message = 'Trip not found.';
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.error('Error loading trip:', err);
        this.message = 'Unable to retrieve trip data.';
      }
    });
  }

  /**
   * Convenience getter for form controls used in template validation.
   */
  get f() {
    return this.editForm.controls;
  }

  /**
   * Handles form submission and updates the trip.
   */
  public onSubmit(): void {
    this.submitted = true;

    if (!this.editForm.valid) {
      this.message = 'Please correct the validation errors before submitting.';
      return;
    }

    this.isLoading = true;
    this.tripDataService.updateTrip(this.editForm.value).subscribe({
      next: () => {
        this.isLoading = false;
        this.router.navigate(['']);
      },
      error: (err) => {
        this.isLoading = false;
        console.error('Trip update failed:', err);
        this.message = 'Failed to update trip. Please try again.';
      }
    });
  }
}
