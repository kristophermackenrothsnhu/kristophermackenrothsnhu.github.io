import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthenticationService } from '../services/authentication';

/**
 * LoginComponent
 *
 * Handles user authentication by collecting credentials and
 * delegating login logic to the AuthenticationService.
 * Provides basic validation and user feedback.
 */
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css'],
})
export class LoginComponent {

  /** User-entered login credentials */
  public credentials = {
    email: '',
    password: ''
  };

  /** Error message displayed to the user */
  public formError = '';

  /** Indicates whether a login request is in progress */
  public isLoading = false;

  constructor(
    private router: Router,
    private authService: AuthenticationService
  ) {}

  /**
   * Handles login form submission.
   * Validates input and attempts authentication through the service.
   */
  public onLoginSubmit(): void {
    this.formError = '';
    this.isLoading = true;

    if (!this.credentials.email || !this.credentials.password) {
      this.formError = 'Email and password are required.';
      this.isLoading = false;
      return;
    }

    this.authService.login(this.credentials.email, this.credentials.password)
      .subscribe({
        next: () => {
          this.isLoading = false;
          // Redirect to trip listing on successful login
          this.router.navigateByUrl('/', { replaceUrl: true });
        },
        error: (err) => {
          console.error('Login failed:', err);
          this.formError = 'Login failed. Please check your credentials.';
          this.isLoading = false;
        }
      });
  }
}
