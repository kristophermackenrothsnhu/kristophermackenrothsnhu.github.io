// src/app/models/auth-response.ts
import { User } from './user';

/**
 * AuthResponse
 *
 * Represents the response returned from the backend after
 * a login or registration request.
 */
export class AuthResponse {
  token: string;
  user: User;

  constructor(token: string = '', user: User = new User()) {
    this.token = token;
    this.user = user;
  }
}
