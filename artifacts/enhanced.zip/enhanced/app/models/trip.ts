/**
 * Trip model
 *
 * Represents a travel trip entity as used throughout
 * the client application.
 *
 * Design Considerations:
 * - Numeric fields use number types to support
 *   efficient filtering and sorting algorithms
 * - Matches backend schema for consistency
 * - Supports scalability for large datasets
 */
export interface Trip {

  /** Internal MongoDB identifier */
  _id?: string;

  /** Public-facing unique trip code */
  code: string;

  /** Human-readable trip name */
  name: string;

  /**
   * Trip duration in days
   *
   * Stored as a number to support:
   * - Range filtering
   * - Numeric sorting
   * - Improved algorithmic efficiency
   */
  length: number;

  /** Trip start date */
  start: Date;

  /** Destination or resort name */
  resort: string;

  /**
   * Cost per person
   *
   * Numeric type enables:
   * - Server-side min/max filtering
   * - Database-optimized sorting
   * - Reduced client-side processing
   */
  perPerson: number;

  /** Image URL */
  image: string;

  /** Trip description */
  description: string;
}
