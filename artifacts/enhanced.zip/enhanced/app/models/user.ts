/**
 * User model
 *
 * Represents an authenticated user within the client application.
 * Mirrors the backend User schema while intentionally limiting
 * sensitive fields for security.
 */
export class User {

  /** MongoDB unique identifier */
  _id: string;

  /** User email address (used for authentication) */
  email: string;

  /** Display name */
  name: string;

  constructor() {
    this._id = '';
    this.email = '';
    this.name = '';
  }
}
