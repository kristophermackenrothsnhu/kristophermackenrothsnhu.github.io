import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';

import { AuthenticationService } from '../services/authentication';

/**
 * NavbarComponent
 *
 * Provides the top-level navigation for the Travlr Getaways Admin application.
 * Displays navigation options based on authentication state and
 * handles user logout and routing.
 */
@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.html',
  styleUrls: ['./navbar.css'],
})
export class NavbarComponent {

  /** Indicates whether a logout action is currently in progress */
  public isLoggingOut = false;

  constructor(
    private authenticationService: AuthenticationService,
    private router: Router
  ) {}

  /**
   * Determines whether the user is currently authenticated.
   * Used to conditionally display navigation links.
   */
  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  /**
   * Logs the user out of the application and redirects to the login page.
   */
  public onLogout(): void {
    this.isLoggingOut = true;

    this.authenticationService.logout();
    this.router.navigate(['login']);

    this.isLoggingOut = false;
  }
}
