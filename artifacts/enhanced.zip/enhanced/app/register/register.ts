import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthenticationService } from '../services/authentication';
import { User } from '../models/user';

/**
 * RegisterComponent
 *
 * Handles user registration for the Travlr Getaways Admin application.
 * Responsible for collecting user credentials, validating input,
 * and delegating registration logic to the AuthenticationService.
 */
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css'],
})
export class RegisterComponent {

  /** User model bound to the registration form */
  public user: User = new User();

  /** Password entered by the user */
  public password = '';

  /** Displays validation or server errors */
  public formError = '';

  /** Indicates form submission in progress */
  public isLoading = false;

  constructor(
    private router: Router,
    private authService: AuthenticationService
  ) {}

  /**
   * Handles form submission for user registration.
   * Performs validation and delegates registration to AuthenticationService.
   */
  public onSubmit(): void {
    this.resetFormState();

    if (!this.isFormValid()) {
      this.formError = 'All fields are required.';
      this.isLoading = false;
      return;
    }

    this.authService.register(this.user, this.password).subscribe({
      next: () => {
        this.isLoading = false;
        this.router.navigate(['']);
      },
      error: (err) => {
        console.error('Registration failed:', err);
        this.formError = 'Registration failed. Please try again.';
        this.isLoading = false;
      }
    });
  }

  /**
   * Validate required form fields.
   */
  private isFormValid(): boolean {
    return !!(this.user.name && this.user.email && this.password);
  }

  /**
   * Reset error and loading states before submission.
   */
  private resetFormState(): void {
    this.formError = '';
    this.isLoading = true;
  }
}
