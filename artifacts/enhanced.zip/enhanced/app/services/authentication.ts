import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { BROWSER_STORAGE } from '../storage';
import { User } from '../models/user';

/**
 * AuthenticationService
 *
 * Handles user authentication, JWT lifecycle management,
 * and persistence of authentication state. This service
 * follows the Single Responsibility Principle by isolating
 * all authentication concerns from the rest of the application.
 */
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  /** Base API URL for authentication endpoints */
  private readonly baseUrl = 'http://localhost:3000/api';

  /** Storage keys for authentication state */
  private readonly TOKEN_KEY = 'auth_token';
  private readonly USER_ID_KEY = 'user_id';
  private readonly USER_EMAIL_KEY = 'user_email';
  private readonly USER_NAME_KEY = 'user_name';

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) {}

  /**
   * Authenticate an existing user.
   * Stores JWT and basic user identity on successful login.
   */
  public login(email: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.baseUrl}/login`, { email, password })
      .pipe(
        map((res) => {
          this.validateAuthResponse(res);
          this.persistAuthState(res);
          return res;
        })
      );
  }

  /**
   * Register a new user and authenticate immediately.
   */
  public register(user: User, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.baseUrl}/register`, {
      name: user.name,
      email: user.email,
      password
    }).pipe(
      map((res) => {
        this.validateAuthResponse(res);
        this.persistAuthState(res);
        return res;
      })
    );
  }

  /**
   * Returns true if a valid JWT exists in storage.
   */
  public isLoggedIn(): boolean {
    return !!this.storage.getItem(this.TOKEN_KEY);
  }

  /**
   * Retrieve the stored JWT token.
   */
  public getToken(): string | null {
    return this.storage.getItem(this.TOKEN_KEY);
  }

  /**
   * Retrieve the currently authenticated user's identity.
   */
  public getCurrentUser(): User | null {
    const id = this.storage.getItem(this.USER_ID_KEY);
    const email = this.storage.getItem(this.USER_EMAIL_KEY);
    const name = this.storage.getItem(this.USER_NAME_KEY);

    if (id && email) {
      return { _id: id, email, name: name || '' };
    }

    return null;
  }

  /**
   * Clear authentication state and log the user out.
   */
  public logout(): void {
    this.storage.removeItem(this.TOKEN_KEY);
    this.storage.removeItem(this.USER_ID_KEY);
    this.storage.removeItem(this.USER_EMAIL_KEY);
    this.storage.removeItem(this.USER_NAME_KEY);
  }

  /**
   * Ensure authentication responses contain required fields.
   */
  private validateAuthResponse(res: AuthResponse): void {
    if (!res.token || !res.user) {
      throw new Error('Invalid authentication response from server');
    }
  }

  /**
   * Persist authentication state to browser storage.
   */
  private persistAuthState(res: AuthResponse): void {
    this.storage.setItem(this.TOKEN_KEY, res.token);
    this.storage.setItem(this.USER_ID_KEY, res.user._id);
    this.storage.setItem(this.USER_EMAIL_KEY, res.user.email);
    this.storage.setItem(this.USER_NAME_KEY, res.user.name || '');
  }
}

/**
 * AuthResponse
 *
 * Strongly typed response returned by authentication endpoints.
 */
export interface AuthResponse {
  token: string;
  user: User;
}
