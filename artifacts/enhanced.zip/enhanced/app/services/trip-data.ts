import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from '../models/trip';

/**
 * Interface describing paginated API responses.
 *
 * Using a typed interface improves maintainability,
 * type safety, and documentation clarity.
 */
export interface PaginatedTripsResponse {
  data: Trip[];
  pagination: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

/**
 * Interface for optional query parameters used when
 * retrieving trips from the API.
 *
 * This abstraction keeps method signatures clean and
 * scalable as additional filters are introduced.
 */
export interface TripQueryParams {
  resort?: string;
  minPrice?: number;
  maxPrice?: number;
  sortBy?: string;
  order?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

/**
 * TripDataService
 *
 * Service-layer abstraction responsible for all Trip-related
 * API interactions.
 *
 * Software Design Principles:
 * - Single Responsibility: Handles only trip data access
 * - Separation of Concerns: UI logic lives in components
 * - Scalability: Supports server-side filtering and pagination
 *
 * Authentication concerns (JWT headers) are handled globally
 * via an HTTP interceptor.
 */
@Injectable({ providedIn: 'root' })
export class TripDataService {

  /** Base API URL for trip-related endpoints */
  private readonly baseUrl = 'http://localhost:3000/api/trips';

  constructor(private http: HttpClient) {}

  /**
   * Retrieve trips using server-side filtering, sorting,
   * and pagination.
   *
   * Algorithmic Benefits:
   * - Reduces time complexity by limiting result sets
   * - Reduces space complexity on both client and server
   * - Avoids unnecessary client-side processing
   *
   * @param params Optional query parameters
   */
  public getTrips(
    params: TripQueryParams = {}
  ): Observable<PaginatedTripsResponse> {

    let httpParams = new HttpParams();

    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        httpParams = httpParams.set(key, value.toString());
      }
    });

    return this.http.get<PaginatedTripsResponse>(this.baseUrl, {
      params: httpParams
    });
  }

  /**
   * Retrieve a single trip by its unique code.
   *
   * @param tripCode Unique identifier for the trip
   */
  public getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.baseUrl}/${tripCode}`);
  }

  /**
   * Create a new trip.
   *
   * @param trip Trip data to persist
   */
  public addTrip(trip: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.baseUrl, trip);
  }

  /**
   * Update an existing trip.
   *
   * @param trip Trip object containing updated data
   */
  public updateTrip(trip: Trip): Observable<Trip> {
    return this.http.put<Trip>(`${this.baseUrl}/${trip.code}`, trip);
  }

  /**
   * Delete a trip by its unique code.
   *
   * @param tripCode Unique identifier for the trip
   */
  public deleteTrip(tripCode: string): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.baseUrl}/${tripCode}`);
  }
}
