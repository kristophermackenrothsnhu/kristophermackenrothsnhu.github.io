import { TestBed } from '@angular/core/testing';
import { BROWSER_STORAGE } from './storage';

describe('BROWSER_STORAGE InjectionToken', () => {
  it('should provide localStorage', () => {
    const storage = TestBed.inject(BROWSER_STORAGE);
    expect(storage).toBe(localStorage);
  });
});
