import { Component, OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Trip } from '../models/trip';
import { AuthenticationService } from '../services/authentication';

/**
 * TripCardComponent
 *
 * Responsible for rendering individual trip details.
 * Provides edit functionality for authenticated users.
 */
@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trip-card.html',
  styleUrls: ['./trip-card.css']
})
export class TripCardComponent implements OnInit {

  /** Trip data passed from parent component */
  @Input() trip: Trip | undefined;

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  /** Angular lifecycle hook */
  ngOnInit(): void {}

  /**
   * Navigate to edit-trip page for the selected trip
   * @param trip Trip object to edit
   */
  public editTrip(trip: Trip): void {
    if (!trip || !trip.code) {
      console.error('editTrip called with invalid trip:', trip);
      return;
    }

    // Clear any previously stored trip code and save the current one
    localStorage.removeItem('tripCode');
    localStorage.setItem('tripCode', trip.code);

    // Navigate to edit page
    this.router.navigate(['edit-trip']);
  }

  /**
   * Check if the user is currently logged in
   * Used to conditionally render UI elements like Edit buttons
   * @returns true if logged in, false otherwise
   */
  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }
}
