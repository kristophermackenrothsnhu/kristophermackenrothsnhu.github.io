// Angular core imports
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

// RxJS operators and helpers
import { catchError, retry } from 'rxjs/operators';
import { of } from 'rxjs';

// Application services and models
import {
  TripDataService,
  PaginatedTripsResponse
} from '../services/trip-data';
import { AuthenticationService } from '../services/authentication';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './trip-listing.html',
  styleUrls: ['./trip-listing.css']
})
export class TripListingComponent implements OnInit {

  /** Array of trips returned from the API */
  public trips: Trip[] = [];

  /** UI state flags */
  public isLoading = false;
  public error = '';

  /** Pagination state */
  public currentPage = 1;
  public pageSize = 6;
  public totalPages = 0;

  /** Sorting state */
  public sortField: 'name' | 'start' | 'perPerson' = 'name';
  public sortDirection: 'asc' | 'desc' = 'asc';

  /**
   * Inject required services:
   * - TripDataService: handles API calls
   * - Router: navigation between routes
   * - AuthenticationService: login state
   */
  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  /**
   * Lifecycle hook runs once when component initializes
   */
  ngOnInit(): void {
    this.loadTrips();
  }

  /** Navigate to Add Trip page */
  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  /** Navigate to Edit Trip page using trip code */
  public editTrip(code: string): void {
    this.router.navigate(['edit-trip', code]);
  }

  /**
   * Delete a trip after user confirmation
   * Refreshes list on success
   */
  public deleteTrip(code: string): void {
    if (!confirm('Are you sure you want to delete this trip?')) {
      return;
    }

    this.tripDataService.deleteTrip(code).subscribe({
      next: () => this.loadTrips(),
      error: () => this.error = 'Failed to delete trip.'
    });
  }

  /** Returns true if user is logged in */
  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  /**
   * Change current page and reload trips
   */
  public changePage(page: number): void {
    if (page < 1 || page > this.totalPages) {
      return;
    }

    this.currentPage = page;
    this.loadTrips();
  }

  /**
   * Loads trips from API with pagination
   * Includes retry and error handling
   */
  private loadTrips(): void {
    this.isLoading = true;
    this.error = '';

    this.tripDataService.getTrips({
      page: this.currentPage,
      limit: this.pageSize
    })
    .pipe(
      // Retry request up to 2 times
      retry(2),

      // Catch errors and prevent app crash
      catchError(err => {
        console.error('Trip load failed:', err);
        this.error = 'Unable to load trips.';
        this.isLoading = false;
        return of(null);
      })
    )
    .subscribe((response: PaginatedTripsResponse | null) => {
      if (!response) {
        return;
      }

      // Assign trip data and pagination info
      this.trips = response.data;
      this.totalPages = response.pagination.totalPages;

      // Apply current sorting
      this.sortTrips();

      this.isLoading = false;
    });
  }

  /**
   * Sort trips based on selected field and direction
   */
  private sortTrips(): void {
    this.trips.sort((a, b) => {
      let valueA: any;
      let valueB: any;

      switch (this.sortField) {

        // Sort alphabetically by name
        case 'name':
          valueA = a.name.toLowerCase();
          valueB = b.name.toLowerCase();
          break;

        // Sort by start date
        case 'start':
          valueA = new Date(a.start).getTime();
          valueB = new Date(b.start).getTime();
          break;

        // Sort by price per person (strip currency symbols)
        case 'perPerson':
          valueA = Number(String(a.perPerson).replace(/[^0-9.]/g, ''));
          valueB = Number(String(b.perPerson).replace(/[^0-9.]/g, ''));
          break;
      }

      // Apply ascending or descending order
      if (valueA < valueB) {
        return this.sortDirection === 'asc' ? -1 : 1;
      }

      if (valueA > valueB) {
        return this.sortDirection === 'asc' ? 1 : -1;
      }

      return 0;
    });
  }

  /**
   * Sets sort field and toggles direction
   * Called when user clicks column headers
   */
  public setSort(field: 'name' | 'start' | 'perPerson'): void {
    if (this.sortField === field) {
      // Toggle direction if same field clicked
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      // New field defaults to ascending
      this.sortField = field;
      this.sortDirection = 'asc';
    }

    this.sortTrips();
  }
}
