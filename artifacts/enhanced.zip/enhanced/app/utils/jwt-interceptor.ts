import { Injectable, Provider } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HTTP_INTERCEPTORS
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../services/authentication';

/**
 * JwtInterceptor
 *
 * Global HTTP interceptor responsible for attaching JSON Web Tokens (JWT)
 * to outgoing API requests.
 *
 * Design Goals:
 * - Centralize authentication header logic
 * - Prevent duplication of auth code across services
 * - Improve security by ensuring all protected endpoints receive a token
 * - Exclude authentication endpoints (login/register) from interception
 */
@Injectable()
export class JwtInterceptor implements HttpInterceptor {

  constructor(private authenticationService: AuthenticationService) {}

  /**
   * Intercepts outgoing HTTP requests before they are sent.
   *
   * Behavior:
   * - Detects authentication-related endpoints
   * - Attaches Authorization header for all other requests
   *   when a user is logged in
   *
   * @param request Outgoing HTTP request
   * @param next HTTP handler in the interceptor chain
   */
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {

    // Identify whether this request targets authentication endpoints
    const isAuthAPI = this.isAuthEndpoint(request.url);

    // Attach JWT only if the user is logged in and the request is not auth-related
    if (this.authenticationService.isLoggedIn() && !isAuthAPI) {
      const token = this.authenticationService.getToken();

      if (token) {
        // Clone the request to preserve immutability and add Authorization header
        const authRequest = request.clone({
          setHeaders: { Authorization: `Bearer ${token}` }
        });

        return next.handle(authRequest);
      }

      // Defensive logging: logged-in state without a token indicates a logic issue
      console.warn('Authentication state inconsistency: token missing.');
    }

    // Forward request unchanged if no token is attached
    return next.handle(request);
  }

  /**
   * Determines whether the request URL is targeting an authentication endpoint.
   *
   * @param url Request URL
   * @returns true if endpoint is login or register
   */
  private isAuthEndpoint(url: string): boolean {
    return url.includes('/login') || url.includes('/register');
  }
}

/**
 * JWT Interceptor Provider
 *
 * Exported separately to allow clean registration
 * within the application configuration.
 */
export const authInterceptProvider: Provider = {
  provide: HTTP_INTERCEPTORS,
  useClass: JwtInterceptor,
  multi: true
};
