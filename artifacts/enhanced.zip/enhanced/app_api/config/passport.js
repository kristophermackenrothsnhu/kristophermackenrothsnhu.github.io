const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const mongoose = require('mongoose');
require('../models/user');

/**
 * User model reference
 * Retrieved from Mongoose after schema registration
 */
const User = mongoose.model('users');

/**
 * Configure Passport Local Strategy
 * Authenticates users using email and password
 */
passport.use(
  new LocalStrategy(
    {
      usernameField: 'email', // Use email instead of default username
    },
    async (email, password, done) => {
      try {
        // Attempt to locate user by email
        const user = await User.findOne({ email }).exec();

        // User not found
        if (!user) {
          return done(null, false, {
            message: 'Incorrect username.',
          });
        }

        // Invalid password
        if (!user.validPassword(password)) {
          return done(null, false, {
            message: 'Incorrect password.',
          });
        }

        // Successful authentication
        return done(null, user);
      } catch (err) {
        // Handle database or unexpected errors
        return done(err);
      }
    }
  )
);
