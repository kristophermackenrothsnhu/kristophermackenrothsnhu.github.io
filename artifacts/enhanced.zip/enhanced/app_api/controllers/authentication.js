const User = require('../models/user');
const passport = require('passport');

/**
 * Register a new user
 * Creates a user account, hashes the password, and returns a JWT
 */
const register = async (req, res) => {
  const { name, email, password } = req.body;

  // Validate required fields
  if (!name || !email || !password) {
    return res.status(400).json({
      message: 'All fields are required',
    });
  }

  try {
    // Create new user instance
    const user = new User({ name, email });

    // Hash and store password
    user.setPassword(password);

    // Save user to database
    await user.save();

    // Generate authentication token
    const token = user.generateJWT();

    // Return token and minimal user data
    return res.status(200).json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
      },
    });
  } catch (err) {
    return res.status(400).json({
      message: 'Registration failed',
      error: err.message,
    });
  }
};

/**
 * Login an existing user
 * Authenticates credentials using Passport and returns a JWT
 */
const login = (req, res) => {
  const { email, password } = req.body;

  // Validate required fields
  if (!email || !password) {
    return res.status(400).json({
      message: 'All fields are required',
    });
  }

  passport.authenticate('local', (err, user, info) => {
    if (err) {
      return res.status(500).json(err);
    }

    if (!user) {
      return res.status(401).json(info);
    }

    // Generate authentication token
    const token = user.generateJWT();

    return res.status(200).json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
      },
    });
  })(req, res);
};

module.exports = {
  register,
  login,
};
