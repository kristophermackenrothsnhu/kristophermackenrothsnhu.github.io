const Trip = require('../models/travlr');

/**
 * GET /trips
 * List trips with filtering, sorting, and pagination
 * Optimized for indexed queries and scalable performance
 */
const tripsList = async (req, res) => {
  try {
    const {
      resort,
      minPrice,
      maxPrice,
      sortBy = 'name',
      order = 'asc',
      page = 1,
      limit = 10
    } = req.query;

    /* ===========================
       Build Filter Object
       =========================== */
    const filter = { userId: req.user._id };

    if (resort) {
      filter.resort = { $regex: resort, $options: 'i' };
    }

    if (minPrice || maxPrice) {
      filter.perPerson = {};
      if (minPrice) filter.perPerson.$gte = Number(minPrice);
      if (maxPrice) filter.perPerson.$lte = Number(maxPrice);
    }

    /* ===========================
       Safe Sorting (Whitelist)
       =========================== */
    const allowedSortFields = ['name', 'start', 'perPerson', 'resort'];
    const sortField = allowedSortFields.includes(sortBy) ? sortBy : 'name';
    const sortOrder = order === 'desc' ? -1 : 1;

    const sortOptions = { [sortField]: sortOrder };

    /* ===========================
       Pagination
       =========================== */
    const pageNumber = Math.max(Number(page), 1);
    const pageSize = Math.min(Math.max(Number(limit), 1), 100);
    const skip = (pageNumber - 1) * pageSize;

    /* ===========================
       Database Queries
       ===========================
       Executed in parallel to reduce latency
    */
    const [trips, totalTrips] = await Promise.all([
      Trip.find(filter)
        .sort(sortOptions)
        .skip(skip)
        .limit(pageSize)
        .exec(),
      Trip.countDocuments(filter)
    ]);

    return res.status(200).json({
      data: trips,
      pagination: {
        total: totalTrips,
        page: pageNumber,
        limit: pageSize,
        totalPages: Math.ceil(totalTrips / pageSize)
      }
    });
  } catch (err) {
    return res.status(500).json({ message: 'Server error', error: err });
  }
};

/**
 * GET /trips/:tripCode
 * Retrieve a single trip owned by the authenticated user
 */
const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip.findOne({
      code: req.params.tripCode,
      userId: req.user._id
    }).exec();

    if (!trip) {
      return res.status(404).json({ message: 'Trip not found' });
    }

    return res.status(200).json(trip);
  } catch (err) {
    return res.status(500).json({ message: 'Server error', error: err });
  }
};

/**
 * POST /trips
 * Create a new trip for the authenticated user
 */
const tripsAddTrip = async (req, res) => {
  try {
    const trip = new Trip({
      ...req.body,
      userId: req.user._id
    });

    const savedTrip = await trip.save();
    return res.status(201).json(savedTrip);
  } catch (err) {
    console.error('Trip save error:', err);
    return res.status(400).json({ message: 'Failed to create trip', error: err });
  }
};

/**
 * PUT /trips/:tripCode
 * Update an existing trip owned by the authenticated user
 */
const tripsUpdateTrip = async (req, res) => {
  try {
    const trip = await Trip.findOneAndUpdate(
      { code: req.params.tripCode, userId: req.user._id },
      req.body,
      { new: true, runValidators: true }
    ).exec();

    if (!trip) {
      return res.status(404).json({ message: 'Trip not found or update failed' });
    }

    return res.status(200).json(trip);
  } catch (err) {
    return res.status(500).json({ message: 'Server error', error: err });
  }
};

/**
 * DELETE /trips/:tripCode
 * Remove a trip owned by the authenticated user
 */
const tripsDeleteTrip = async (req, res) => {
  try {
    const trip = await Trip.findOneAndDelete({
      code: req.params.tripCode,
      userId: req.user._id
    }).exec();

    if (!trip) {
      return res.status(404).json({ message: 'Trip not found or already deleted' });
    }

    return res.status(200).json({ message: 'Trip deleted successfully' });
  } catch (err) {
    return res.status(500).json({ message: 'Server error', error: err });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};
