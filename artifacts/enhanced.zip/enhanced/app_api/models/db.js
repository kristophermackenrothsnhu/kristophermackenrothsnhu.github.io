const mongoose = require('mongoose');
const readline = require('readline');

/**
 * Database Configuration
 *
 * Centralized MongoDB connection management using Mongoose.
 * Handles connection lifecycle, error handling, retry logic,
 * and graceful shutdown for production-ready stability.
 */

const host = process.env.DB_HOST || '127.0.0.1';
const dbName = process.env.DB_NAME || 'travlr';
const dbURI = `mongodb://${host}/${dbName}`;

// Connection options for stability and performance
const mongooseOptions = {
  autoIndex: false,               // Disable auto index creation in production
  serverSelectionTimeoutMS: 5000, // Fail fast if MongoDB is unreachable
};

/**
 * Establish MongoDB connection with retry support
 */
const connectWithRetry = async () => {
  try {
    await mongoose.connect(dbURI, mongooseOptions);
  } catch (err) {
    console.error('❌ MongoDB connection failed. Retrying in 5 seconds...');
    setTimeout(connectWithRetry, 5000);
  }
};

/* ===========================
   Connection Event Monitoring
   =========================== */

mongoose.connection.on('connected', () => {
  console.log(`✅ Mongoose connected to ${dbURI}`);
});

mongoose.connection.on('error', err => {
  console.error('❌ Mongoose connection error:', err);
});

mongoose.connection.on('disconnected', () => {
  console.log('⚠️  Mongoose disconnected');
});

/* ===========================
   Graceful Shutdown Handling
   =========================== */

/**
 * Close Mongoose connection safely
 */
const gracefulShutdown = message => {
  mongoose.connection.close(() => {
    console.log(`🔌 Mongoose disconnected through ${message}`);
  });
};

// Windows-specific SIGINT support
if (process.platform === 'win32') {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  rl.on('SIGINT', () => {
    process.emit('SIGINT');
  });
}

// Nodemon restart
process.once('SIGUSR2', () => {
  gracefulShutdown('nodemon restart');
  process.kill(process.pid, 'SIGUSR2');
});

// App termination (Ctrl+C)
process.on('SIGINT', () => {
  gracefulShutdown('application termination');
  process.exit(0);
});

// Container shutdown (Docker / cloud)
process.on('SIGTERM', () => {
  gracefulShutdown('container shutdown');
  process.exit(0);
});

/* ===========================
   Initialize Connection
   =========================== */

connectWithRetry();

// Import Mongoose models
require('./travlr');
require('./user');

module.exports = mongoose;
