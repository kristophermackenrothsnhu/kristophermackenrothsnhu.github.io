/**
 * Database Seeder
 *
 * Seeds the database with initial trip data for development/testing.
 * This script:
 * - Establishes a database connection
 * - Clears existing trip data
 * - Inserts seed records
 * - Closes the database connection gracefully
 *
 * NOTE:
 * Seeded trips must be associated with a valid userId
 * to comply with authorization rules.
 */

const mongoose = require('./db');
const Trip = require('./travlr');
const fs = require('fs');
const path = require('path');

// Load seed data
const tripsFilePath = path.join(__dirname, '../data/trips.json');
const trips = JSON.parse(fs.readFileSync(tripsFilePath, 'utf8'));

/**
 * Seed database with trip data
 */
const seedDB = async () => {
  try {
    console.log('🌱 Seeding database...');

    // WARNING: This deletes all existing trips
    await Trip.deleteMany({});
    console.log('🗑️ Existing trips removed');

    /**
     * IMPORTANT:
     * All trips must have a userId.
     * Replace the ObjectId below with a real user ID
     * from your users collection.
     */
    const USER_ID = new mongoose.Types.ObjectId(
      process.env.SEED_USER_ID || '000000000000000000000000'
    );

    const seededTrips = trips.map(trip => ({
      ...trip,
      userId: USER_ID
    }));

    await Trip.insertMany(seededTrips);
    console.log(`✅ ${seededTrips.length} trips inserted`);
  } catch (err) {
    console.error('❌ Seeding failed:', err);
  } finally {
    mongoose.connection.close(() => {
      console.log('🔌 Database connection closed');
      process.exit(0);
    });
  }
};

// Run seeder
seedDB();
