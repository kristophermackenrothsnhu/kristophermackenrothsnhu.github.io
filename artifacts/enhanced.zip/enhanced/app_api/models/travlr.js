const mongoose = require('mongoose');

/**
 * Trip Schema
 *
 * Represents a single travel trip owned by a specific user.
 * Designed with performance, data integrity, and secure
 * multi-user access in mind.
 */
const tripSchema = new mongoose.Schema(
  {
    /** Unique trip code (used for lookup, updates, deletes) */
    code: {
      type: String,
      required: true,
      trim: true,
      uppercase: true
    },

    /** Trip name (used for sorting and searching) */
    name: {
      type: String,
      required: true,
      trim: true
    },

    /** Trip duration (stored as string for display consistency) */
    length: {
      type: String,
      required: true,
      trim: true
    },

    /** Trip start date (used for sorting and filtering) */
    start: {
      type: Date,
      required: true
    },

    /** Destination / resort (used for filtering) */
    resort: {
      type: String,
      required: true,
      trim: true
    },

    /**
     * Cost per person
     * Stored as Number to enable numeric comparisons and sorting
     */
    perPerson: {
      type: Number,
      required: true,
      min: [0, 'Price must be a positive value']
    },

    /** Image URL */
    image: {
      type: String,
      required: true,
      trim: true,
      match: [/^https?:\/\//, 'Image must be a valid URL']
    },

    /** Trip description */
    description: {
      type: String,
      required: true,
      trim: true
    },

    /**
     * Owner of the trip
     * Associates each trip with the authenticated user
     */
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'users',
      required: true
    }
  },
  {
    timestamps: true // Automatically track createdAt and updatedAt
  }
);

/* ===========================
   Indexes for Performance
   =========================== */

/**
 * Compound index to enforce per-user ownership and
 * optimize secure trip lookups.
 */
tripSchema.index({ code: 1, userId: 1 }, { unique: true });

/**
 * Index for retrieving all trips belonging to a user.
 * Optimized for pagination and dashboard views.
 */
tripSchema.index({ userId: 1 });

/**
 * Indexes supporting filtering and sorting operations.
 * Improves query performance for large datasets.
 */
tripSchema.index({ resort: 1 });
tripSchema.index({ perPerson: 1 });
tripSchema.index({ start: 1 });
tripSchema.index({ name: 1 });

/**
 * Export Trip model
 */
module.exports = mongoose.model('trips', tripSchema);
