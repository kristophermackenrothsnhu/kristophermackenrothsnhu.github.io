const mongoose = require('mongoose');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

/**
 * User Schema
 *
 * Defines the structure and behavior of user records.
 * This schema emphasizes security, data integrity, and
 * production-ready database practices.
 */
const userSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      unique: true,
      required: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, 'Please use a valid email address']
    },
    name: {
      type: String,
      required: true,
      trim: true
    },
    hash: String,
    salt: String
  },
  {
    timestamps: true // Automatically adds createdAt and updatedAt fields
  }
);

/**
 * Hashes and salts a plain-text password before persistence.
 * Ensures passwords are never stored or transmitted in clear text.
 *
 * @param {string} password - The user's plain-text password
 */
userSchema.methods.setPassword = function (password) {
  this.salt = crypto.randomBytes(16).toString('hex');
  this.hash = crypto
    .pbkdf2Sync(password, this.salt, 1000, 64, 'sha512')
    .toString('hex');
};

/**
 * Compares a supplied password with the stored hash.
 *
 * @param {string} password - Password provided during login
 * @returns {boolean} True if the password is valid
 */
userSchema.methods.validPassword = function (password) {
  const hash = crypto
    .pbkdf2Sync(password, this.salt, 1000, 64, 'sha512')
    .toString('hex');

  return this.hash === hash;
};

/**
 * Generates a JSON Web Token (JWT) for authenticated access.
 * The token contains minimal identifying information and
 * expires after one hour for improved security.
 *
 * @returns {string} Signed JWT
 */
userSchema.methods.generateJWT = function () {
  return jwt.sign(
    {
      _id: this._id,
      email: this.email,
      name: this.name
    },
    process.env.JWT_SECRET,
    { expiresIn: '1h' }
  );
};

/**
 * Export User model
 */
module.exports = mongoose.model('users', userSchema);
