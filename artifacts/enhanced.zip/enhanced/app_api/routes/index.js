const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

/** Auth routes */
router.post('/register', authController.register);
router.post('/login', authController.login);

/** Trips routes */
router.get('/trips', authenticateJWT, tripsController.tripsList);
router.get('/trips/:tripCode', authenticateJWT, tripsController.tripsFindByCode);
router.post('/trips', authenticateJWT, tripsController.tripsAddTrip);
router.put('/trips/:tripCode', authenticateJWT, tripsController.tripsUpdateTrip);

// DELETE route for trips
router.delete('/trips/:tripCode', authenticateJWT, tripsController.tripsDeleteTrip);

/** Middleware: authenticate JWT */
function authenticateJWT(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return res.sendStatus(401);

  const token = authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ message: 'Invalid token' });

    // Set req.user to decoded payload so all controllers use the same property
    req.user = decoded;
    next();
  });
}


module.exports = router;
